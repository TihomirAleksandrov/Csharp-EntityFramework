﻿using System;

namespace SoftUni
{
    internal class Startup
    {
        static void Main(string[] args)
        {
            
        }
    }
}
